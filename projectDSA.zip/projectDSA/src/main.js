class Activity {
  constructor(name, start, end) {
    this.name = name;
    this.start = start;
    this.end = end;
  }
}

class ActivitySelector {
  constructor() {
    this.activities = [];
    this.maxTime = 24; // Default max time (24 hours)
    this.initializeUI();
    this.selectedActivities = [];
  }

  initializeUI() {
    // Initialize DOM elements
    this.addActivityBtn = document.getElementById('addActivity');
    this.solveBtn = document.getElementById('solve');
    this.nameInput = document.getElementById('activityName');
    this.startInput = document.getElementById('startTime');
    this.endInput = document.getElementById('endTime');
    this.timelineEl = document.getElementById('timeline');
    this.activitiesListEl = document.getElementById('activitiesList');
    this.selectedActivitiesEl = document.getElementById('selectedActivities');

    // Add event listeners
    this.addActivityBtn.addEventListener('click', () => this.addActivity());
    this.solveBtn.addEventListener('click', () => this.solve());

    // Initialize timeline scale
    this.initializeTimelineScale();
  }

  initializeTimelineScale() {
    const scaleEl = document.querySelector('.timeline-scale');
    scaleEl.innerHTML = '';
    for (let i = 0; i <= this.maxTime; i += 2) {
      const mark = document.createElement('span');
      mark.textContent = i;
      scaleEl.appendChild(mark);
    }
  }

  addActivity() {
    const name = this.nameInput.value;
    const start = parseInt(this.startInput.value);
    const end = parseInt(this.endInput.value);

    if (!name || isNaN(start) || isNaN(end)) {
      alert('Please fill all fields with valid values');
      return;
    }

    if (start >= end) {
      alert('End time must be greater than start time');
      return;
    }

    if (start < 0 || end > this.maxTime) {
      alert(`Time must be between 0 and ${this.maxTime}`);
      return;
    }

    const activity = new Activity(name, start, end);
    this.activities.push(activity);
    this.renderActivities();
    this.clearInputs();
  }

  clearInputs() {
    this.nameInput.value = '';
    this.startInput.value = '';
    this.endInput.value = '';
  }

  renderActivities() {
    // Clear previous renders
    this.timelineEl.innerHTML = '';
    this.activitiesListEl.innerHTML = '';

    // Render activities on timeline
    this.activities.forEach((activity, index) => {
      const activityEl = document.createElement('div');
      activityEl.className = 'activity-bar';
      activityEl.style.left = `${(activity.start / this.maxTime) * 100}%`;
      activityEl.style.width = `${((activity.end - activity.start) / this.maxTime) * 100}%`;
      activityEl.style.top = `${(index * 40) + 10}px`;
      activityEl.textContent = activity.name;
      this.timelineEl.appendChild(activityEl);

      // Render in activities list
      const listItem = document.createElement('div');
      listItem.className = 'activity-item';
      listItem.innerHTML = `
        <span>${activity.name} (${activity.start} - ${activity.end})</span>
        <button onclick="activitySelector.removeActivity(${index})">Remove</button>
      `;
      this.activitiesListEl.appendChild(listItem);
    });
  }

  removeActivity(index) {
    this.activities.splice(index, 1);
    this.renderActivities();
  }

  solve() {
    if (this.activities.length === 0) {
      alert('Please add some activities first');
      return;
    }

    // Sort activities by end time
    const sortedActivities = [...this.activities].sort((a, b) => a.end - b.end);
    
    // Select activities
    this.selectedActivities = [];
    let lastEnd = 0;

    sortedActivities.forEach(activity => {
      if (activity.start >= lastEnd) {
        this.selectedActivities.push(activity);
        lastEnd = activity.end;
      }
    });

    this.renderSelectedActivities();
    this.highlightSelectedActivities();
  }

  renderSelectedActivities() {
    this.selectedActivitiesEl.innerHTML = '';
    
    this.selectedActivities.forEach(activity => {
      const listItem = document.createElement('div');
      listItem.className = 'activity-item';
      listItem.innerHTML = `
        <span>${activity.name} (${activity.start} - ${activity.end})</span>
      `;
      this.selectedActivitiesEl.appendChild(listItem);
    });
  }

  highlightSelectedActivities() {
    const activityBars = document.querySelectorAll('.activity-bar');
    activityBars.forEach(bar => bar.classList.remove('selected'));

    this.selectedActivities.forEach(selected => {
      activityBars.forEach(bar => {
        if (bar.textContent === selected.name) {
          bar.classList.add('selected');
        }
      });
    });
  }
}

// Initialize the application
const activitySelector = new ActivitySelector();
// Make it globally accessible for the onclick handlers
window.activitySelector = activitySelector;